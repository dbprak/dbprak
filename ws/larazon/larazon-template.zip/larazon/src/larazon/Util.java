package larazon;

/**
 * Put all utility classes and static helper functions here!
 */
public class Util {
	
	/**
	 * You need a class to represent a book? Use a "public static class" inside Util.
	 */
	public static class Book {
		// TODO
	}

	/**
	 * Functions that are needed in more than one servlet can be defined here.
	 */
	public static void someUtilFunction(Object o) {
	}
}
