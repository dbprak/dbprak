package larazon.shopping;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet for submitting an order. See the wiki for details.
 */
@WebServlet("/OrderCart")
public class OrderCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Resource(mappedName="java:jboss/datasources/LARAZON")
	private DataSource ds;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderCart() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED);	
	}
}
