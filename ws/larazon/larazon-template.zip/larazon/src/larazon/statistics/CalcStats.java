package larazon.statistics;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Calculates the statistical data. See the wiki for details.
 */
@WebServlet("/CalcStats")
public class CalcStats extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Resource(mappedName="java:jboss/datasources/LARAZON")
	private DataSource ds;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalcStats() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED);	
	}
}
