package larazon.statistics;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Returns the tracking data. See the wiki for details.
 */
@WebServlet("/ShowTrackingData")
public class ShowTrackingData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Resource(mappedName="java:jboss/datasources/LARAZON")
	private DataSource ds;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowTrackingData() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED);	
	}
}
