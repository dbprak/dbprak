package larazon.statistics;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

/**
 * Servlet Filter for tracking certain requests (SearchBooks, AddToCart, OrderCart). See the wiki for details.
 */
public class TrackingFilter implements Filter {

	@Resource(mappedName = "java:jboss/datasources/LARAZON")
	private DataSource ds;

	/**
	 * Default constructor.
	 */
	public TrackingFilter() {
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;

		// Preprocess: insert code here that needs to be executed before the request is passed to the corresponding servlet.

		chain.doFilter(request, response);

		// Postprocess: insert code here that is executed after the servlet processed the request. 
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
