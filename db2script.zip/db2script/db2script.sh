#!/bin/sh
SCRIPT=$(readlink -f "$0")
SCRIPTPATH=$(dirname "$SCRIPT")

java -cp $SCRIPTPATH/bin:$SCRIPTPATH/lib/*:$SCRIPTPATH/config db2script.Main $@